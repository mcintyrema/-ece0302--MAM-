#ifndef _SORT_HPP
#define _SORT_HPP

#include "linked_list.hpp"

template<typename T> LinkedList<T> sort(LinkedList<T> list)
{
	Node<T>*head = new Node<T>();
	for(size_t i = 0; i < list.getLength(); i++){
		head = mergeSort(head);
		createList(head);
		//list.setEntry(i, *head);
		head = head->getNext();
	}
	
	return list;
}


template<typename T> Node<T>* findingMid(Node<T> *head){
	Node<T>* midFinder = head;
	Node<T>* endFinder = head->getNext();
	while(endFinder != NULL && endFinder->getNext() != NULL){
		midFinder = midFinder->getNext();
		endFinder = (endFinder->getNext())->getNext();
	}
	return midFinder;
}

template<typename T> Node<T>* merge(Node<T> *left, Node<T> *right){
	Node<T>* tempHead = new Node<T>();
	Node<T>* curr = tempHead;

	while(left != NULL && right != NULL){
		if(left->getItem() <= right->getItem()){
			curr->setNext(left);
			left = left->getNext();
			curr = curr->getNext();
		}
		else if(left->getItem() > right->getItem()){
			curr->setNext(right);
			right = right->getNext();
			curr = curr->getNext();
		}
	}
	return tempHead->getNext();
}

template<typename T> Node<T>* mergeSort(Node<T>* start){
	if(start->getNext() == NULL){
		return start;
	}

	Node<T>*middle = findingMid(start);
	 Node<T>*start_of_right = middle->getNext();

	 middle->setNext(NULL);

	 Node<T>*left = mergeSort(start);
	 Node<T>*right = mergeSort(start_of_right);

	 Node<T>*new_head = merge(left, right);

	 return new_head;
}

template<typename T>LinkedList<T> push(Node<T> *ptrHead){
	Node<T>*temp = new Node<T>();
	
	temp->setNext(ptrHead);

	LinkedList<T>a;
	//a.setEntry(0, *ptrHead);
	
	return a;
}

template<typename T>LinkedList<T> createList(Node<T> *nodeAdd){
	LinkedList<T>list;
	while(nodeAdd != NULL){
		nodeAdd = nodeAdd->getNext();
		push(nodeAdd);
	}
	return list;
}

#endif
