#define CATCH_CONFIG_MAIN
#define CATCH_CONFIG_COLOUR_NONE
#include "catch.hpp"
#include "FindPalindrome.hpp"

// There should be at least one test per FindPalindrome method

TEST_CASE( "Test adding a non-allowable word", "[FindPalindrome]" )
{
	FindPalindrome b;
	REQUIRE(!b.add("kayak1"));
}

TEST_CASE("testing clear function", "[FindPalindrome"){
	FindPalindrome a;

	// adding strings
	a.add("chapstick");
	a.add("hippo");
	a.add("koala");
	a.add("kayak");

	a.clear();
	REQUIRE(a.number() == 0);

	FindPalindrome b;
	b.add("a");
	b.add("aAa");
	b.add("AA");
	
	b.clear();
	REQUIRE(b.number() == 0);

	FindPalindrome c;
	std::vector<std::string>temp;
	temp.push_back("naill");
	temp.push_back("harry");
	temp.push_back("liam");
	temp.push_back("louis");

	c.add(temp);
	c.clear();
	REQUIRE(c.number()==0);
}

TEST_CASE("test number returns correct number of palindromes", "[FindPalindrome]"){
	FindPalindrome b;
	
	REQUIRE(b.add("a"));
	REQUIRE(b.add("AA"));
	REQUIRE(b.add("AaA"));
	
	REQUIRE(b.number() == 6);
}

TEST_CASE("test cutTest1 with valid word", "[FindPalindrome"){
	FindPalindrome a;
	std::vector<std::string>b;
	b.push_back("kayak");
	REQUIRE(a.cutTest1(b) == true);
}

TEST_CASE("test recursion", "[FindPalindrome]"){
	FindPalindrome a;
	
	a.add("a");
	a.add("aAa");
	a.add("AA");

	REQUIRE(a.number() == 6);
}

TEST_CASE("testing add string works", "[FindPalindrome]"){
	FindPalindrome a;

	REQUIRE(a.add("kayak"));
	REQUIRE(a.add("chapstick"));
	REQUIRE(!a.add("ke$ha"));
	REQUIRE(!a.add("me+you"));
	REQUIRE(!a.add("kayak"));
}

TEST_CASE("testing add vector works", "[FindPalindrome]"){
	FindPalindrome a;
	std::vector<std::string>sentence;
	std::vector<std::string>sentence2;

	sentence2.push_back("chandler<3");
	sentence2.push_back("RACH3L");
	REQUIRE(!a.add(sentence2));

	sentence.push_back("Ross");
	sentence.push_back("phoebe");
	sentence.push_back("MONICA");
	sentence.push_back("joey");
	REQUIRE(a.add(sentence));

}

TEST_CASE("Just checking add", "[FindPalindrome"){
	FindPalindrome a;
	REQUIRE(a.add("a"));
	REQUIRE(a.add("AA"));
	REQUIRE(a.add("AaA"));

}

TEST_CASE("test cut test 1", "[FindPalindrome]"){
	FindPalindrome a;
	std::vector<std::string>b;
	b.push_back("kayak1");
	REQUIRE(a.cutTest1(b) == false);

	b.push_back("non");
	b.push_back("joj");
	b.push_back("m0m");
	REQUIRE(a.cutTest1(b) == true);

	b.push_back("m");
	REQUIRE(a.cutTest1(b) == false);
}

TEST_CASE("toVector returns vector of strings", "[FindPalindrome]"){
	FindPalindrome a;
	std::vector<std::vector<std::string>>sen;
	FindPalindrome b;
	std::vector<std::vector<std::string>>sen2;

	a.add("Yoda");
	a.add("Skywalker");
	a.add("jedi");

	sen = a.toVector();
	REQUIRE(sen[0][0] == "Yoda");
	REQUIRE(sen[0][1]== "Skywalker");
	REQUIRE(sen[0][2] == "jedi");


	b.add("a");
	b.add("AA");
	b.add("aAa");
	
	REQUIRE(sen2[0][0] == "a");
	REQUIRE(sen2[0][1] == "AA");
	REQUIRE(sen2[0][2] == "aAa");
	REQUIRE(sen2[1][0] == "a");
	REQUIRE(sen2[1][1] == "aAa");
	REQUIRE(sen2[1][2] == "AA");
	REQUIRE(sen2[2][0] == "AA");
	REQUIRE(sen2[2][1] == "a");
	REQUIRE(sen2[2][2] == "aAa");
}