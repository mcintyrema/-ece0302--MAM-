#include "bitset.hpp"

Bitset::Bitset() {
    uint8_t* bptr = new uint8_t[8];
    for(uint8_t i = 0; i <= 7; i++){
        *(bptr + i) = 0;
    }

}

Bitset::Bitset(intmax_t size) {
    intmax_t N;

    if(N <= 0){
        validity = false;
    }
    else{
        validity = true;
    }

    uint8_t* bptr = new uint8_t[N];
    for(uint8_t i = 0; i < N; i++){
        *(bptr + i) = 0;
    }
    
}

Bitset::Bitset(const std::string & value) {
    std::string* bptr = new std::string[value.length()];
    
    for(int i = 0; i < value.length(); i++){
        bptr[i] = value.substr(i);

        if(bptr[i] != "1" || bptr[i] != "0"){
        validity = false;
        }
    }
    
}

Bitset::~Bitset() {
    delete [] bptr;
    delete [] *bptr;
}

intmax_t Bitset::size() const {
    return sizeof(*bptr);
}

bool Bitset::good() const {
    return validity;
}

void Bitset::set(intmax_t index) {
    *bptr[index] = 1;

    if(index < 0 || index > size()){
        validity = false;
    }
}

void Bitset::reset(intmax_t index) {
    *bptr[index] = 0;

    if(index < 0 || index > size()){
        validity = false;
    }
}

void Bitset::toggle(intmax_t index) {
    if(*bptr[index] == 1){
        *bptr[index] = 0;
    }
    else if(*bptr[index] == 0){
        *bptr[index] = 1;
    }
    else{
        validity = false;
    }
    
    if(index < 0 || index > size()){
        validity = false;
    }
}

bool Bitset::test(intmax_t index) {
    
    if(*bptr[index] == 1){
         sett = true;
         return sett;
    }
    else if(*bptr[index] == 0){
        sett = false;
        return sett;
    }
    else{
        return false;
    }

    if(index < 0 || index > size()){
        return false;
    }
}

std::string Bitset::asString() const {

    std::stringstream stream;
    std::string bitString[sizeof(*bptr)];
    std::string bitWord;

    for(int i = 0; i < sizeof(*bptr); i++){
        stream << *(bptr + i);
        stream >> bitString[i];
        bitWord = bitWord + bitString[i];
    }

    return bitWord;
}

