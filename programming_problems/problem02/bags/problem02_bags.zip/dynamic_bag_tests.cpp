#define CATCH_CONFIG_MAIN
#include "catch.hpp"
#include <string>

#include "dynamic_bag.hpp"

// force template expansion for ints
template class DynamicBag<int>;

TEST_CASE("Calling all public members", "[DynamicBag]"){
  DynamicBag<int> b;

  b.add(0);
  b.remove(0);
  b.isEmpty();
  b.getCurrentSize();
  b.clear();
  b.getFrequencyOf(0);
  b.contains(0);
}

TEST_CASE("Calling Copy onstructor", "[Dynamic Bag]"){
  DynamicBag<int> a;
  DynamicBag<int> b(a);
}

TEST_CASE("Bag initialized to zero and empty", "[Dynamic Bag]"){
  DynamicBag<int> a;

  REQUIRE(a.getCurrentSize() == 0);
  REQUIRE(a.isEmpty() == true);

  DynamicBag<int> b(a);
  REQUIRE(b.isEmpty() == true);
  REQUIRE(b.getCurrentSize() == 0);
  
}

TEST_CASE("getCurrentSize returns number of items in bag", "[Dynamic Bag]"){
   DynamicBag<int>b;
   int size = 7;
  b.setCurrentSize(size);
  REQUIRE(b.getCurrentSize() == 7);
}

TEST_CASE("bag can be cleared", "[DynamicBag]"){
  DynamicBag<int>a;
  // setItemsInBox(a);
  REQUIRE(a.isEmpty() == true);
}

TEST_CASE("remove returns false if item not found", "[DynamicBag]"){
  DynamicBag<std::string>a;

  std::string item;

  if(a.getFrequencyOf(item) == 0){
    REQUIRE(a.remove(item) == false);
  }
  else{
    REQUIRE(a.remove(item) == true);
  }
}




TEST_CASE("Test copy constructor", "[DynamicBag]"){
  DynamicBag<int>bag1;
  DynamicBag<int>bag2 = bag1;

  REQUIRE(&bag1.operator=(bag2) == &bag1);
}



TEST_CASE("add shows if item added", "[Dynamic Bag"){
  DynamicBag<std::string> a;

  std::string item = "chapstick";
  bool check;
  check = a.add(item);

  REQUIRE(check == true);
}

TEST_CASE("count frequency of item", "[DynamicBag]"){
  DynamicBag<std::string>a;
  std::string item = "wallet";

 // for(int i = 0; i < 9; i++){
   // a.add(item);  // add item 9 times
 // }
  a.add(item);
  a.add(item);
  a.add(item);
  REQUIRE(a.contains(item) == true);
  REQUIRE(a.getFrequencyOf(item) == 3);
}


TEST_CASE("contains returns true for item", "[DynamicBag]"){
  DynamicBag<std::string>a;

  std::string item;
  a.add(item); // adding item to bag

  REQUIRE(a.contains(item) == true);
}

TEST_CASE("items can be removed one at a time", "[DynamicBag]"){
  DynamicBag<std::string> a;
  std::string item = "chapstick";
  REQUIRE(a.remove(item) == false);
}