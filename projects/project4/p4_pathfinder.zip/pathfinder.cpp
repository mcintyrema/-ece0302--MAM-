#include <cstdlib>
#include <iostream>
#include "lib/image.h"
#include "dynamic_array_list.hpp"
#include "queue.hpp"


//function prototypes
void start(Image<Pixel>& image);
void bfs(Image<Pixel>& image);
bool finish(Image<Pixel>& image);
//Queue<int, DynamicArrayList<int>> actions(Image<Pixel>& image);
//bool present(Queue<int, DynamicArrayList<int>> d);



//initializing coordinates check
int x = -1;
int y = -1;

int main(int argc, char *argv[])
{
  // get input/output file names from command line arguments
  if (argc != 3) {
    std::cout << "Usage: pathfinder "
              << "<first_input_filename> <second_output_filename>\n"
              << std::endl;
    return EXIT_FAILURE;
  }

  std::string input_file = argv[1];
  std::string output_file = argv[2];

  // Read input image from file
  Image<Pixel> image = readFromFile(input_file);
  //call breadth first search
  bfs(image);


  // Write solution image to file
  writeToFile(image, output_file);
  return EXIT_SUCCESS;
}


//getting initial point
void start(Image<Pixel>& image)
{
  //number of red pixels
  int redNum;

  // Loop through all of the pixels
  for (int i = 0; i < image.height(); i++)
  {
    for (int j = 0; j < image.width(); j++)
    {
      // If red pixel found, set coordinates to initial positions
      if (image(i, j) == RED)
      {
        x = i; //startx = i
        y = j; //starty = j
        redNum++;
      }
      // Error check
      //might not need x != -1 && y != -1
      else if ((image(i, j) != WHITE && image(i, j) != RED && image(i, j) != BLACK))
      {
        x = -1;
        y = -1;
        return;
      }
    }
  }

  //check number of red pixels
  if(redNum > 1){
    std::cerr << "More than one start pixel." << std::endl;
    //return EXIT_FAILURE;
  }
}


//////////////////////////
//breadth first search returns solution or failure
//////////////////////////
void bfs(Image<Pixel>& image)
{
  bool solutionFound = false;
  start(image);
  //queue frontier and add starting pixel
  Queue<std::pair<int, int>, DynamicArrayList<int>> frontier;
  std::pair<int, int> s(x, y);
  frontier.enqueue(s);

  // check to see if at goal
  if (finish(image) || (x == -1 && y == -1))
    return;


  bool explored[image.width()][image.height()];
  std::pair<int, int> location;
  int a, b;
  

  while (!frontier.isEmpty())
  {
    //pop next location to explore
    location = frontier.peekFront();
    a = location.first;
    b = location.second;
    frontier.dequeue();

    //mark location as explored
    explored[a][b] = 1;

    //check for edge of maze
    if(image(a,b) == WHITE && (a ==0 || a == image.width()-1 || b == 0 || b == image.height()-1)){
      solutionFound = true;
      image(a, b) = GREEN;
      break;
    }
  //////////////////////
  //checking states/////
  /////////////////////

  //check left
  if(image(a-1, b) == WHITE && !explored[a-1][b]){
    frontier.enqueue(std::pair<int, int>(a-1,b));
    explored[a-1][b] = 1;
  }
  //check right
  if (image(a+1,b) == WHITE && !explored[a+1][b]) {
      frontier.enqueue(std::pair<int,int>(a+1,b));
      explored[a+1][b] = 1;
  }
  //check up
  if (image(a,b+1) == WHITE && !explored[a][b+1]) {
      frontier.enqueue(std::pair<int,int>(a,b+1));
      explored[a][b+1] = 1;
  }
  //check down
  if (image(a,b-1) == WHITE && !explored[a][b-1]) {
      frontier.enqueue(std::pair<int,int>(a,b-1));
      explored[a][b-1] = 1;
  }

  //save solution
  //writeToFile(image, argv[2]);

  }
}




// Function that returns if the current position is the goal state
bool finish(Image<Pixel>& image)
{
  // If on boundary, set to green and return true
  if (x == 0 || y == 0 || x == image.height() - 1 || y == image.width() - 1)
  {
    image(x, y) = GREEN;
    return true;
  }
  else
    return false;
}


/*
// Function that returns possible moves
Queue<int, DynamicArrayList<int>> actions(Image<Pixel>& image)
{
  Queue<int, DynamicArrayList<int>> arr;

  if (x > 0 && image(x - 1, y) == WHITE)
  {
    arr.enqueue(x - 1);
    arr.enqueue(y);
  }
  if (x + 1 < image.width() && image(x + 1, y) == WHITE)
  {
    arr.enqueue(x + 1);
    arr.enqueue(y);
  }
  if (y > 0 && image(x, y - 1) == WHITE)
  {
    arr.enqueue(x);
    arr.enqueue(y - 1);
  }
  if (y + 1 < image.height() && image(x, y + 1) == WHITE)
  {
    arr.enqueue(x);
    arr.enqueue(y + 1);
  }

  return arr;
}

// Function that checks if the coordinates match
bool present(Queue<int, DynamicArrayList<int>> d)
{
  // Loop through all values in deque
  while (!d.isEmpty())
  {
    if (d.peekFront() == x)
    {
      d.dequeue();
      if (d.peekFront() == y)
        return true;
      d.dequeue();
    }
    else
    {
      d.dequeue();
      d.dequeue();
    }
  }

  return false;
}

*/
