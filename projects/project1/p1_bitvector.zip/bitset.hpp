#ifndef BITSET_HPP
#define BITSET_HPP
#include <stdint.h>
#include <stdlib.h>
#include <string>
#include <sstream>
#include <iostream>rm

class Bitset{
public:

  // defualt constructor
  Bitset();

  // bitset of size N
  Bitset(intmax_t size);

  // bitset initialized with a string
  Bitset(const std::string & value);

  // destructor
  ~Bitset();

  Bitset(const Bitset & ) = delete;
  Bitset & operator=(const Bitset &) = delete;

  // size of bitset
  intmax_t size() const;

  // determines if bitset is valid
  bool good() const;

  // sets the nth bit
  void set(intmax_t index);

  // resets the nth bit
  void reset(intmax_t index);

  // toggles the nth bit
  void toggle(intmax_t index);

  // check if nth bit is set
  bool test(intmax_t index);

  // returns bitset as string of characters
  std::string asString() const;

private:

  // member variable that tells if instance of class is valid
  bool validity;

  //member variable for testing if set
  bool sett;

  //bitset array variable of size 8
  std::int8_t* bptr[8];
};

#endif
