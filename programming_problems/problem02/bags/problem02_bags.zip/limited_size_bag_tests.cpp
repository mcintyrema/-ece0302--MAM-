#define CATCH_CONFIG_MAIN
#include "catch.hpp"

#include "limited_size_bag.hpp"

// force template expansion for ints
template class LimitedSizeBag<int>;

TEST_CASE("Empty Test", "[LimitedSizeBag]"){
  REQUIRE(true);
}

TEST_CASE("Calling all public members", "[LimitedSizeBag]"){
  LimitedSizeBag<int>a;

  a.add(0);
  a.remove(0);
  a.isEmpty();
  a.getCurrentSize();
  a.clear();
  a.getFrequencyOf(0);
  a.contains(0);
}

TEST_CASE("Calling Copy onstructor", "[Limited Size Bag]"){
  LimitedSizeBag<int> a;
  LimitedSizeBag<int> b(a);
}

TEST_CASE("Bag initialized to zero and empty", "[Limited Size Bag]"){
  LimitedSizeBag<int> a;

  REQUIRE(a.getCurrentSize() == 0);
  REQUIRE(a.isEmpty() == true);

  LimitedSizeBag<int> b(a);
  REQUIRE(b.isEmpty() == true);
  REQUIRE(b.getCurrentSize() == 0);
  
}

TEST_CASE("getCurrentSize returns number of items in bag", "[Limited Size Bag]"){
   LimitedSizeBag<int>b;
   int size = 7;
  b.setCurrentSize(size);
  REQUIRE(b.getCurrentSize() == 7);
}

TEST_CASE("bag can be cleared", "[Limited Size Bag]"){
  LimitedSizeBag<int>a;
  // setItemsInBox(a);
  REQUIRE(a.isEmpty() == true);
}

TEST_CASE("remove returns false if item not found", "[Limited Size Bag]"){
  LimitedSizeBag<std::string>a;

  std::string item;

  if(a.getFrequencyOf(item) == 0){
    REQUIRE(a.remove(item) == false);
  }
  else{
    REQUIRE(a.remove(item) == true);
  }
}


TEST_CASE("Test copy constructor", "[Limited Size Bag]"){
  LimitedSizeBag<int>bag1;
  LimitedSizeBag<int>bag2 = bag1;

  REQUIRE(&bag1.operator=(bag2) == &bag1);
}



TEST_CASE("add shows if item added", "[Limited Size Bag]"){
  LimitedSizeBag<std::string> a;

  std::string item = "chapstick";
  bool check;
  check = a.add(item);

  REQUIRE(check == true);
}

TEST_CASE("count frequency of item", "[Limited Size Bag]"){
  LimitedSizeBag<std::string>a;
  std::string item = "wallet";

 // for(int i = 0; i < 9; i++){
   // a.add(item);  // add item 9 times
 // }
  a.add(item);
  a.add(item);
  a.add(item);
  REQUIRE(a.contains(item) == true);
  REQUIRE(a.getFrequencyOf(item) == 3);
}


TEST_CASE("contains returns true for item", "[Limited Size Bag]"){
  LimitedSizeBag<std::string>a;

  std::string item;
  a.add(item); // adding item to bag

  REQUIRE(a.contains(item) == true);
}

TEST_CASE("items can be removed one at a time", "[Limited Size Bag]"){
  LimitedSizeBag<std::string> a;
  std::string item = "chapstick";
  REQUIRE(a.remove(item) == false);
}
