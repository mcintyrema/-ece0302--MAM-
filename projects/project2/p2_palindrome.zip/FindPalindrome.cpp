#include <string>
#include <vector>
#include <iostream>
#include <locale> 
#include <algorithm>
#include <iostream>
#include "FindPalindrome.hpp"

using namespace std;

//------------------- HELPER FUNCTIONS -----------------------------------------

// non-class helper functions go here, should be declared as "static" so that
// their scope is limited

// helper function to convert string to lower case
static void convertToLowerCase(string & value)
{
	locale loc;
	for (int i=0; i<value.size(); i++) {
		value[i] = tolower(value[i],loc);
	}
}

//------------------- PRIVATE CLASS METHODS ------------------------------------

// private recursive function. Must use this signature!
void FindPalindrome::recursiveFindPalindromes(vector<string>
        candidateStringVector, vector<string> currentStringVector)
{
	if(!cutTest2(candidateStringVector,currentStringVector))
			{
				return; // exit if vectors cut from test
			}	
	//if no pals in current vector add candidates	
	if( currentStringVector.size() == 0){
		std::string maybe;
		for(int i = 0; i<candidateStringVector.size();i++)
		{
			//concatenating string with words from candidate vector
			maybe += candidateStringVector[i]; 
		}

		//if string is a pal, add to vector of pal vectors
		if(isPalindrome(maybe))
		{
			vecOfVecs.push_back(candidateStringVector);	
			return;
		}
	}
	//for the length of the candidate pals vector, add the current pals to the
	//candidate vector while removing candidate just added	
	for(int i=0;i<currentStringVector.size();i++)
	{	
		candidateStringVector.push_back(currentStringVector[i]); 
		currentStringVector.erase(currentStringVector.begin()+i); 

		//recall recursive function now that parameters have been changed
		//from the above lines
		recursiveFindPalindromes(candidateStringVector,currentStringVector);

		//inserting new candidate to beginning of current pal vector and deleting from candidate 
		//vector
		currentStringVector.insert(currentStringVector.begin()+i,candidateStringVector.back());
		candidateStringVector.pop_back(); 
	}	
}

// private function to determine if a string is a palindrome (given, you
// may change this if you want)
bool FindPalindrome::isPalindrome(string currentString) const
{
	locale loc;
	// make sure that the string is lower case...
	convertToLowerCase(currentString);
	// see if the characters are symmetric...
	int stringLength = currentString.size();
	for (int i=0; i<stringLength/2; i++) {
		if (currentString[i] != currentString[stringLength - i - 1]) {
			return false;
		}
	}

	return true; 
}

//------------------- PUBLIC CLASS METHODS -------------------------------------

FindPalindrome::FindPalindrome()
{
	// TODO need to implement this...
	dim = 0;
}

FindPalindrome::~FindPalindrome()
{
	dim = 0;
	clear();
}

int FindPalindrome::number() const
{
	// TODO need to implement this...
	return vecOfVecs.size();
}

void FindPalindrome::clear()
{
	// TODO need to implement this...
	words.clear(); //Clearing word vector
	vecOfVecs.clear(); //Clearing the vector of known palindromes
}

bool FindPalindrome::cutTest1(const vector<string> & stringVector)
{
	string pal;

	//concatenating string with strings form vector
	for(int i = 0; i < stringVector.size(); i++){
		pal += stringVector[i];
	}

	//convert concatenated string to acceptable form
	convertToLowerCase(pal);

	//variable with valid palindrome characters
	//and filling with zeros
	int goodChars[26];
	for(int i = 0; i < 26; i++){
		goodChars[i] = 0;
	}

	//converting characters of palindrome string to intergers
	//to compare if character at most appears an odd # of times
	for(int i = 0; i < pal.size(); i++){
		int j = static_cast<int>(pal[i]);
		goodChars[j-97]++;
	} 

	//does string have even number of characters
	bool even = (pal.size()%2 == 0);

	int charsOdd = 0;
	//count occurence of char in palindrome is valid
	for(int i = 0; i < 26; i++){
		charsOdd += (goodChars[i]%2 == 1);
		//count of each char must be even if string is even length
		if(charsOdd != 0 && even){ 
			return false;
		}
		//center char must appear odd number of times if string is odd
		if(charsOdd > 1 && !even){
			return false;
		}
	}

	return true;
}


//This function tests to see if the letter is also in the other bigger half
bool FindPalindrome::cutTest2(const vector<string> & stringVector1,
                              const vector<string> & stringVector2)
{
	std::string temp = "";
	std::string temp2 = "";

	//concatenating temp with strings in vector
	for(int i=0; i<stringVector1.size();i++){
		temp += stringVector1[i];
	}

	//concatenating temp2 with strings in full vector
	for(int i=0; i<stringVector2.size();i++){
		temp2 += stringVector2.at(i);
	}

	//splitting palindrome
	std::string left;
	std::string right;
	
	if(temp.length() <= temp2.length()){
		left = temp;
		right = temp2;
	}
	else{
		left = temp2;
		right = temp;
	}

	//how many times does string appear on left and right sides of pal
	convertToLowerCase(left);
	convertToLowerCase(right);
	int occurrence = 0;
	for(int i = 0; i < left.length(); i++)
	{
		occurrence = 0;
		for(int j=0; j < right.length(); j++){
			if(left[i] == right[j]){
				//increment occurence when characters in left appear in right
				occurrence++;	
			}
		}
		if(occurrence == 0) {return false;}
	}
	return true;
}

bool FindPalindrome::add(const string & value)
{
	string temp;
	temp = value; 
	size_t size = value.length();
	bool validity[size]; 
	string validCharacters = "abcdefghijklmnopqrstuvwxyz";
	string temp2;

	convertToLowerCase(temp); 

	//check if string already included in vector
	for(int i = 0; i < words.size(); i++){
		temp2 = words[i]; 
		convertToLowerCase(temp2); 
		//temp holds all strings in words
		//compare all strings in words to string parameter
		//if string matches parameter, return false, do not add
		if(temp.compare(temp2) == 0)
		{
			return false; 
		}
	}

	//check if all characters of value are valid
	//cycles through a-z before moving to temp's next char
	for(int i = 0; i < value.length(); i++){
		validity[i] = false;
		for(int j = 0; j < validCharacters.length();j++){
			//if character i of string matches a-z, the string is valid
			if(temp[i] == validCharacters[j]){
				validity[i] = true;
			}
		}
	}

	//validity holds whether each char is valid from string
	//if any char invalid, return false
	for(int i = 0; i < value.length(); i++){
		if(validity[i] == false){
			return false; 
		}
	}
	//add parameter to words vector
	words.push_back(value); 

	vector<string>emptyVec;
	if(cutTest1(words) == true) //running cut test with new value
	{
		vecOfVecs.clear();
		recursiveFindPalindromes(emptyVec,words); 

	}
	return true; 
}

bool FindPalindrome::add(const vector<string> & stringVector)
{
	//declare vars
	string temp; 
	string temp2; 
	string container;
	string charsValid = "abcdefghijklmnopqrstuvwxyz"; 
	
	//creating temp string with parameter string
	for(int i = 0; i < stringVector.size(); i++){
		temp = stringVector[i]; 
		convertToLowerCase(temp); 
		bool validity[temp.length()];

		//checking is chars in string are only a-z
		for(int j = 0; j < temp.length(); j++){
			validity[j] = false;
			for(int k=0;k<charsValid.length();k++){
				if(temp[j] == charsValid[k]){
					validity[j] = true;
				}
			}
			//if there are chars not a-z, do not add string
			if(validity[j] == false){
				return false;
			}
		}
		
		for(int j = 0; j < words.size(); j++){
			temp2 = words[j];
			convertToLowerCase(temp2);
			//compare function returns zero if two strings are the same
			if(temp.compare(temp2) == 0){
				//if string is a duplicate, do not add to vector
				//string was already part of words vector
				return false;
			}
		}
		//is the user trying to add two duplicate strings in parameter
		for(int j=0;j<stringVector.size();j++){
			if(i == j){
				j++;
			}
			if(j == stringVector.size()){
				break;
			}
			temp2 = stringVector[j];
			convertToLowerCase(temp2);
			//do not add string vector if it contains duplicate strings
			if(temp.compare(temp2) == 0){
				return false;
			}
		}
	}

	//add input string vector to words
	for(int i=0;i<stringVector.size();i++){
		words.push_back(stringVector[i]); 
	}

	//empty vector for candidate string of recursive function
	vector<string> emptyVec;
	
	if(cutTest1(words) == true){
		vecOfVecs.clear();
		recursiveFindPalindromes(emptyVec,words); 

	}
	return true; 
}

vector< vector<string> > FindPalindrome::toVector() const
{
	// TODO need to implement this...
	return vecOfVecs;

}