#ifndef _ADJACENCY_LIST_GRAPH_H_
#define _ADJACENCY_LIST_GRAPH_H_

#include "abstract_graph.hpp"

template <typename LabelType>
class AdjacencyListGraph: public AbstractGraph<LabelType>
{
    public:

        AdjacencyListGraph();
        
        int getNumVertices() const;
        
        int getNumEdges() const;

        //add EDGES(or vertices if nonexistenxt)
        bool add(LabelType start, LabelType end);

        bool remove(LabelType start, LabelType end);

        void depthFirstTraversal(LabelType start, void visit(LabelType&));

        void breadthFirstTraversal(LabelType start, void visit(LabelType&));

        //std::vector<int> adj;

            std::list<int> *adjLists;
            std::map<LabelType, std::list <pair <LabelType, int>>> l;
        
     private:
        int numVertices;
        int numEdges;
        //vector<int> adj[];   

       

};

#include "adjacency_list_graph.tpp"

#endif 
